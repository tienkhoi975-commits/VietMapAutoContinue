#import <UIKit/UIKit.h>
#import <objc/message.h>

static NSString * const VMTargetBundle = @"vn.vietmap.live";

static BOOL VMTextMatches(NSString *text) {
    if (![text isKindOfClass:[NSString class]] || text.length == 0)
        return NO;

    NSString *s = [text stringByTrimmingCharactersInSet:
                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];

    NSArray *targets = @[
        @"Tiếp tục sử dụng V3",
        @"Tiếp tục sử dụng V3!",
        @"Tiếp tục",
        @"Continue using V3",
        @"Continue"
    ];

    for (NSString *target in targets) {
        if ([s caseInsensitiveCompare:target] == NSOrderedSame)
            return YES;

        if ([s rangeOfString:target
                     options:NSCaseInsensitiveSearch].location != NSNotFound)
            return YES;
    }
    return NO;
}

static BOOL VMActivate(id object) {
    if (!object)
        return NO;

    SEL selector = NSSelectorFromString(@"accessibilityActivate");
    if (![object respondsToSelector:selector])
        return NO;

    @try {
        BOOL (*sendMessage)(id, SEL) =
            (BOOL (*)(id, SEL))objc_msgSend;
        return sendMessage(object, selector);
    } @catch (__unused NSException *exception) {
        return NO;
    }
}

static BOOL VMObjectMatches(id object) {
    if (!object)
        return NO;

    NSArray *keys = @[
        @"accessibilityLabel",
        @"accessibilityValue",
        @"accessibilityHint",
        @"accessibilityIdentifier"
    ];

    for (NSString *key in keys) {
        @try {
            id value = [object valueForKey:key];
            if ([value isKindOfClass:[NSString class]] &&
                VMTextMatches(value) &&
                VMActivate(object)) {
                return YES;
            }
        } @catch (__unused NSException *exception) {}
    }
    return NO;
}

static BOOL VMScanAccessibilityArray(NSArray *elements) {
    if (![elements isKindOfClass:[NSArray class]])
        return NO;

    for (id element in elements) {
        if (!element)
            continue;

        if (VMObjectMatches(element))
            return YES;

        @try {
            if ([element respondsToSelector:@selector(accessibilityElements)]) {
                NSArray *children = [element accessibilityElements];
                if (children && children != elements &&
                    VMScanAccessibilityArray(children))
                    return YES;
            }
        } @catch (__unused NSException *exception) {}
    }
    return NO;
}

static BOOL VMScanView(UIView *view) {
    if (!view || view.hidden || view.alpha < 0.01)
        return NO;

    if ([view isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)view;
        NSString *title = [button titleForState:UIControlStateNormal];

        BOOL match =
            VMTextMatches(title) ||
            VMTextMatches(button.accessibilityLabel) ||
            VMTextMatches(button.accessibilityValue) ||
            VMTextMatches(button.accessibilityIdentifier);

        if (match && button.enabled && button.userInteractionEnabled) {
            [button sendActionsForControlEvents:UIControlEventTouchUpInside];
            return YES;
        }
    }

    if (VMObjectMatches(view))
        return YES;

    @try {
        if (VMScanAccessibilityArray(view.accessibilityElements))
            return YES;
    } @catch (__unused NSException *exception) {}

    if (view.isAccessibilityElement &&
        VMTextMatches(view.accessibilityLabel) &&
        VMActivate(view)) {
        return YES;
    }

    for (UIView *child in [view.subviews copy]) {
        if (VMScanView(child))
            return YES;
    }

    return NO;
}

static NSArray *VMWindows(void) {
    NSMutableArray *result = [NSMutableArray array];
    UIApplication *app = UIApplication.sharedApplication;

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in app.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]])
                continue;

            UIWindowScene *ws = (UIWindowScene *)scene;
            [result addObjectsFromArray:ws.windows ?: @[]];
        }
    } else {
        [result addObjectsFromArray:app.windows ?: @[]];
    }

    return [[result reverseObjectEnumerator] allObjects];
}

static BOOL VMScan(void) {
    if (![[NSBundle mainBundle].bundleIdentifier
          isEqualToString:VMTargetBundle])
        return NO;

    for (UIWindow *window in VMWindows()) {
        if (!window || window.hidden || window.alpha < 0.01)
            continue;

        if (VMScanView(window))
            return YES;
    }
    return NO;
}

static void VMScheduleScan(void);

static void VMRunScan(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!VMScan())
            VMScheduleScan();
    });
}

static void VMScheduleScan(void) {
    static NSInteger attempts = 0;

    attempts++;
    if (attempts > 120) {
        attempts = 0;
        return;
    }

    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW,
                      (int64_t)(0.25 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            VMRunScan();
        });
}

static void VMAccessibilityNotification(
    CFNotificationCenterRef center,
    void *observer,
    CFStringRef name,
    const void *object,
    CFDictionaryRef userInfo) {
    VMRunScan();
}

%ctor {
    if (![[NSBundle mainBundle].bundleIdentifier
          isEqualToString:VMTargetBundle])
        return;

    dispatch_async(dispatch_get_main_queue(), ^{
        dispatch_after(
            dispatch_time(DISPATCH_TIME_NOW,
                          (int64_t)(1.5 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                VMRunScan();
            });

        CFNotificationCenterAddObserver(
            CFNotificationCenterGetMainCenter(), NULL,
            VMAccessibilityNotification,
            CFSTR("UIAccessibilityLayoutChangedNotification"),
            NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);

        CFNotificationCenterAddObserver(
            CFNotificationCenterGetMainCenter(), NULL,
            VMAccessibilityNotification,
            CFSTR("UIAccessibilityScreenChangedNotification"),
            NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
    });
}
